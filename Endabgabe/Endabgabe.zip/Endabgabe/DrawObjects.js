var Endabgabe;
(function (Endabgabe) {
    class DrawObjects {
        draw() {
        }
        ;
        move() {
        }
        ;
    }
    Endabgabe.DrawObjects = DrawObjects;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=DrawObjects.js.map