namespace Endabgabe {

    export class DrawObjects {
        xPos: number;
        yPos: number;
        xDir: number;
        yDir: number;


        draw(): void {

        };

        move(): void {

        };
    }
}